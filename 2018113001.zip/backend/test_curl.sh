curl 'http://localhost:9001/register' -H 'Content-Type: application/x-www-form-urlencoded' --data 'name=Animesh&password=Olympics&pconfirm=Olympics&email=AnimeshSinha1309@gmail.com'
curl 'http://localhost:9001/login' -H 'Content-Type: application/x-www-form-urlencoded' --data 'password=picapica&email=sak@mail.co'
